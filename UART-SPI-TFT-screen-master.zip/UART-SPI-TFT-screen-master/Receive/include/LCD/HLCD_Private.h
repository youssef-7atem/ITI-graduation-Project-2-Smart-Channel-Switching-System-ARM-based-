/*
 * LCD_Private.h
 *
 *  Created on: Apr 23, 2024
 *      Author: yoels
 */

#ifndef LCD_PRIVATE_H_
#define LCD_PRIVATE_H_


#define DDRAM_OFFSET 		0x40


#endif /* LCD_PRIVATE_H_ */
