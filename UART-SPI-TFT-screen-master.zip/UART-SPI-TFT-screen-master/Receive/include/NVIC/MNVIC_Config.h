/*
 * MNVIC_Config.h
 *
 *  Created on: Feb 7, 2024
 *      Author: yoels
 */

#ifndef MNVIC_CONFIG_H_
#define MNVIC_CONFIG_H_





#endif /* MNVIC_CONFIG_H_ */
