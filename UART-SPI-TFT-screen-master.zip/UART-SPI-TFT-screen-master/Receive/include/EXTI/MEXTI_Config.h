/*
 * MEXTI_Config.h
 *
 *  Created on: Feb 9, 2024
 *      Author: yoels
 */

#ifndef MEXTI_CONFIG_H_
#define MEXTI_CONFIG_H_

#define MEXTI_NUMBER			2



#endif /* MEXTI_CONFIG_H_ */
