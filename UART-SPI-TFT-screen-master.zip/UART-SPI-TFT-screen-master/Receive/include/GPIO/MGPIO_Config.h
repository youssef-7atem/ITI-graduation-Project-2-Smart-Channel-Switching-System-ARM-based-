/*
 * MGPIO_Config.h
 *
 *  Created on: Feb 5, 2024
 *      Author: yoels
 */

#ifndef MGPIO_CONFIG_H_
#define MGPIO_CONFIG_H_





#endif /* MGPIO_CONFIG_H_ */
