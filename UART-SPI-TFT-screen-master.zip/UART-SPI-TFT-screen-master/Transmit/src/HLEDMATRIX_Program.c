/*
 * HLEDMATRIX_Program.c
 *
 *  Created on: Feb 18, 2024
 *      Author: yousi
 */

/*****************LIB*************************/
#include "../include/BIT_MATH.h"
#include "../include/STD_Types.h"


/*****************MCAL***********************/
#include "../include/GPIO/MGPIO_Interface.h"
#include "../include/STK/MSTK_Interface.h"


/********************HAL********************/
#include "../include/LEDMATRIX/HLEDMATRIX_Interface.h"
#include "../include/LEDMATRIX/HLEDMATRIX_Private.h"
#include "../include/LEDMATRIX/HLEDMATRIX_Config.h"

/********************FUNCTIONS DEFINITIONS********************/

void HLEDMATRIX_voidInit(void)
{
	/**************PORTA***************/
	MGPIO_voidSetPinMode(GPIO_PORTA, GPIO_PIN0,GPIO_OUTPUT);
	MGPIO_voidSetPinOutputMode(GPIO_PORTA, GPIO_PIN0,GPIO_PUSH_PULL,GPIO_LOW_SPEED);

	MGPIO_voidSetPinMode(GPIO_PORTA, GPIO_PIN1,GPIO_OUTPUT);
	MGPIO_voidSetPinOutputMode(GPIO_PORTA, GPIO_PIN1,GPIO_PUSH_PULL,GPIO_LOW_SPEED);

	MGPIO_voidSetPinMode(GPIO_PORTA, GPIO_PIN2,GPIO_OUTPUT);
	MGPIO_voidSetPinOutputMode(GPIO_PORTA, GPIO_PIN2,GPIO_PUSH_PULL,GPIO_LOW_SPEED);

	MGPIO_voidSetPinMode(GPIO_PORTA, GPIO_PIN3,GPIO_OUTPUT);
	MGPIO_voidSetPinOutputMode(GPIO_PORTA, GPIO_PIN3,GPIO_PUSH_PULL,GPIO_LOW_SPEED);

	MGPIO_voidSetPinMode(GPIO_PORTA, GPIO_PIN4,GPIO_OUTPUT);
	MGPIO_voidSetPinOutputMode(GPIO_PORTA, GPIO_PIN4,GPIO_PUSH_PULL,GPIO_LOW_SPEED);

	MGPIO_voidSetPinMode(GPIO_PORTA, GPIO_PIN5,GPIO_OUTPUT);
	MGPIO_voidSetPinOutputMode(GPIO_PORTA, GPIO_PIN5,GPIO_PUSH_PULL,GPIO_LOW_SPEED);

	MGPIO_voidSetPinMode(GPIO_PORTA, GPIO_PIN6,GPIO_OUTPUT);
	MGPIO_voidSetPinOutputMode(GPIO_PORTA, GPIO_PIN6,GPIO_PUSH_PULL,GPIO_LOW_SPEED);

	MGPIO_voidSetPinMode(GPIO_PORTA, GPIO_PIN7,GPIO_OUTPUT);
	MGPIO_voidSetPinOutputMode(GPIO_PORTA, GPIO_PIN7,GPIO_PUSH_PULL,GPIO_LOW_SPEED);

	/**************PORTB***************/

	MGPIO_voidSetPinMode(GPIO_PORTB, GPIO_PIN0,GPIO_OUTPUT);
	MGPIO_voidSetPinOutputMode(GPIO_PORTB, GPIO_PIN0,GPIO_PUSH_PULL,GPIO_LOW_SPEED);

	MGPIO_voidSetPinMode(GPIO_PORTB, GPIO_PIN1,GPIO_OUTPUT);
	MGPIO_voidSetPinOutputMode(GPIO_PORTB, GPIO_PIN1,GPIO_PUSH_PULL,GPIO_LOW_SPEED);

	MGPIO_voidSetPinMode(GPIO_PORTB, GPIO_PIN2,GPIO_OUTPUT);
	MGPIO_voidSetPinOutputMode(GPIO_PORTB, GPIO_PIN2,GPIO_PUSH_PULL,GPIO_LOW_SPEED);

	MGPIO_voidSetPinMode(GPIO_PORTB, GPIO_PIN5,GPIO_OUTPUT);
	MGPIO_voidSetPinOutputMode(GPIO_PORTB, GPIO_PIN5,GPIO_PUSH_PULL,GPIO_LOW_SPEED);

	MGPIO_voidSetPinMode(GPIO_PORTB, GPIO_PIN6,GPIO_OUTPUT);
	MGPIO_voidSetPinOutputMode(GPIO_PORTB, GPIO_PIN6,GPIO_PUSH_PULL,GPIO_LOW_SPEED);

	MGPIO_voidSetPinMode(GPIO_PORTB, GPIO_PIN7,GPIO_OUTPUT);
	MGPIO_voidSetPinOutputMode(GPIO_PORTB, GPIO_PIN7,GPIO_PUSH_PULL,GPIO_LOW_SPEED);

	MGPIO_voidSetPinMode(GPIO_PORTB, GPIO_PIN8,GPIO_OUTPUT);
	MGPIO_voidSetPinOutputMode(GPIO_PORTB, GPIO_PIN8,GPIO_PUSH_PULL,GPIO_LOW_SPEED);

	MGPIO_voidSetPinMode(GPIO_PORTB, GPIO_PIN9,GPIO_OUTPUT);
	MGPIO_voidSetPinOutputMode(GPIO_PORTB, GPIO_PIN9,GPIO_PUSH_PULL,GPIO_LOW_SPEED);

}
void HLEDMATRIX_voidDisableColumns(void)
{
//	MGPIO_voidSetPinValue(GPIO_PORTA, GPIO_PIN0,GPIO_PIN_LOW);
//	MGPIO_voidSetPinValue(GPIO_PORTA, GPIO_PIN1,GPIO_PIN_LOW);
//	MGPIO_voidSetPinValue(GPIO_PORTA, GPIO_PIN2,GPIO_PIN_LOW);
//	MGPIO_voidSetPinValue(GPIO_PORTA, GPIO_PIN3,GPIO_PIN_LOW);
//	MGPIO_voidSetPinValue(GPIO_PORTA, GPIO_PIN4,GPIO_PIN_LOW);
//	MGPIO_voidSetPinValue(GPIO_PORTA, GPIO_PIN5,GPIO_PIN_LOW);
//	MGPIO_voidSetPinValue(GPIO_PORTA, GPIO_PIN6,GPIO_PIN_LOW);
//	MGPIO_voidSetPinValue(GPIO_PORTA, GPIO_PIN7,GPIO_PIN_LOW);

	/* for the Project */

		MGPIO_voidSetPinValue(GPIO_PORTA, GPIO_PIN11,GPIO_PIN_LOW);
		MGPIO_voidSetPinValue(GPIO_PORTA, GPIO_PIN12,GPIO_PIN_LOW);
		MGPIO_voidSetPinValue(GPIO_PORTA, GPIO_PIN13,GPIO_PIN_LOW);
		MGPIO_voidSetPinValue(GPIO_PORTA, GPIO_PIN14,GPIO_PIN_LOW);
		MGPIO_voidSetPinValue(GPIO_PORTA, GPIO_PIN15,GPIO_PIN_LOW);

		MGPIO_voidSetPinValue(GPIO_PORTB, GPIO_PIN0,GPIO_PIN_LOW);
		MGPIO_voidSetPinValue(GPIO_PORTB, GPIO_PIN1,GPIO_PIN_LOW);
		MGPIO_voidSetPinValue(GPIO_PORTB, GPIO_PIN2,GPIO_PIN_LOW);
}
void HLEDMATRIX_voidSetRowValue(u8 copy_u8RowValue)
{
//	MGPIO_voidSetPinValue(GPIO_PORTB, GPIO_PIN0, !GET_BIT(copy_u8RowValue,0)); /** 0 -> refers to bit not pin number*/
//	MGPIO_voidSetPinValue(GPIO_PORTB, GPIO_PIN1, !GET_BIT(copy_u8RowValue,1));
//	MGPIO_voidSetPinValue(GPIO_PORTB, GPIO_PIN2, !GET_BIT(copy_u8RowValue,2));
//	MGPIO_voidSetPinValue(GPIO_PORTB, GPIO_PIN5, !GET_BIT(copy_u8RowValue,3));
//	MGPIO_voidSetPinValue(GPIO_PORTB, GPIO_PIN6, !GET_BIT(copy_u8RowValue,4));
//	MGPIO_voidSetPinValue(GPIO_PORTB, GPIO_PIN7, !GET_BIT(copy_u8RowValue,5));
//	MGPIO_voidSetPinValue(GPIO_PORTB, GPIO_PIN8, !GET_BIT(copy_u8RowValue,6));
//	MGPIO_voidSetPinValue(GPIO_PORTB, GPIO_PIN9, !GET_BIT(copy_u8RowValue,7));

	/* FOR THE PROJECT*/

	MGPIO_voidSetPinValue(GPIO_PORTB, GPIO_PIN5, !GET_BIT(copy_u8RowValue,3));
	MGPIO_voidSetPinValue(GPIO_PORTB, GPIO_PIN6, !GET_BIT(copy_u8RowValue,4));
	MGPIO_voidSetPinValue(GPIO_PORTB, GPIO_PIN7, !GET_BIT(copy_u8RowValue,5));
	MGPIO_voidSetPinValue(GPIO_PORTB, GPIO_PIN8, !GET_BIT(copy_u8RowValue,6));
	MGPIO_voidSetPinValue(GPIO_PORTB, GPIO_PIN9, !GET_BIT(copy_u8RowValue,7));
	MGPIO_voidSetPinValue(GPIO_PORTB, GPIO_PIN10, !GET_BIT(copy_u8RowValue,0));
	MGPIO_voidSetPinValue(GPIO_PORTB, GPIO_PIN12, !GET_BIT(copy_u8RowValue,1));
	MGPIO_voidSetPinValue(GPIO_PORTB, GPIO_PIN13, !GET_BIT(copy_u8RowValue,2));
}
void HLEDMATRIX_voidDisplay(u8 *copy_u8Array)
{
//	HLEDMATRIX_voidDisableColumns();
//	HLEDMATRIX_voidSetRowValue(copy_u8Array[0]);
//	MGPIO_voidSetPinValue(GPIO_PORTA, GPIO_PIN0,GPIO_PIN_HIGH);
//	MSTK_voidDelayus(2500);
//
//	HLEDMATRIX_voidDisableColumns();
//	HLEDMATRIX_voidSetRowValue(copy_u8Array[1]);
//	MGPIO_voidSetPinValue(GPIO_PORTA, GPIO_PIN1,GPIO_PIN_HIGH);
//	MSTK_voidDelayus(2500);
//
//	HLEDMATRIX_voidDisableColumns();
//	HLEDMATRIX_voidSetRowValue(copy_u8Array[2]);
//	MGPIO_voidSetPinValue(GPIO_PORTA, GPIO_PIN2,GPIO_PIN_HIGH);
//	MSTK_voidDelayus(2500);
//
//	HLEDMATRIX_voidDisableColumns();
//	HLEDMATRIX_voidSetRowValue(copy_u8Array[3]);
//	MGPIO_voidSetPinValue(GPIO_PORTA, GPIO_PIN3,GPIO_PIN_HIGH);
//	MSTK_voidDelayus(2500);
//
//	HLEDMATRIX_voidDisableColumns();
//	HLEDMATRIX_voidSetRowValue(copy_u8Array[4]);
//	MGPIO_voidSetPinValue(GPIO_PORTA, GPIO_PIN4,GPIO_PIN_HIGH);
//	MSTK_voidDelayus(2500);
//
//	HLEDMATRIX_voidDisableColumns();
//	HLEDMATRIX_voidSetRowValue(copy_u8Array[5]);
//	MGPIO_voidSetPinValue(GPIO_PORTA, GPIO_PIN5,GPIO_PIN_HIGH);
//	MSTK_voidDelayus(2500);
//
//	HLEDMATRIX_voidDisableColumns();
//	HLEDMATRIX_voidSetRowValue(copy_u8Array[6]);
//	MGPIO_voidSetPinValue(GPIO_PORTA, GPIO_PIN6,GPIO_PIN_HIGH);
//	MSTK_voidDelayus(2500);
//
//	HLEDMATRIX_voidDisableColumns();
//	HLEDMATRIX_voidSetRowValue(copy_u8Array[7]);
//	MGPIO_voidSetPinValue(GPIO_PORTA, GPIO_PIN7,GPIO_PIN_HIGH);
//	MSTK_voidDelayus(2500);

	/* FOR THR PROJECT*/

		HLEDMATRIX_voidDisableColumns();
		HLEDMATRIX_voidSetRowValue(copy_u8Array[0]);
		MGPIO_voidSetPinValue(GPIO_PORTA, GPIO_PIN11,GPIO_PIN_HIGH);
		MSTK_voidDelayus(2500);

		HLEDMATRIX_voidDisableColumns();
		HLEDMATRIX_voidSetRowValue(copy_u8Array[1]);
		MGPIO_voidSetPinValue(GPIO_PORTA, GPIO_PIN12,GPIO_PIN_HIGH);
		MSTK_voidDelayus(2500);

		HLEDMATRIX_voidDisableColumns();
		HLEDMATRIX_voidSetRowValue(copy_u8Array[2]);
		MGPIO_voidSetPinValue(GPIO_PORTA, GPIO_PIN13,GPIO_PIN_HIGH);
		MSTK_voidDelayus(2500);

		HLEDMATRIX_voidDisableColumns();
		HLEDMATRIX_voidSetRowValue(copy_u8Array[3]);
		MGPIO_voidSetPinValue(GPIO_PORTA, GPIO_PIN14,GPIO_PIN_HIGH);
		MSTK_voidDelayus(2500);

		HLEDMATRIX_voidDisableColumns();
		HLEDMATRIX_voidSetRowValue(copy_u8Array[4]);
		MGPIO_voidSetPinValue(GPIO_PORTA, GPIO_PIN15,GPIO_PIN_HIGH);
		MSTK_voidDelayus(2500);

		HLEDMATRIX_voidDisableColumns();
		HLEDMATRIX_voidSetRowValue(copy_u8Array[5]);
		MGPIO_voidSetPinValue(GPIO_PORTB, GPIO_PIN0,GPIO_PIN_HIGH);
		MSTK_voidDelayus(2500);

		HLEDMATRIX_voidDisableColumns();
		HLEDMATRIX_voidSetRowValue(copy_u8Array[6]);
		MGPIO_voidSetPinValue(GPIO_PORTB, GPIO_PIN1,GPIO_PIN_HIGH);
		MSTK_voidDelayus(2500);

		HLEDMATRIX_voidDisableColumns();
		HLEDMATRIX_voidSetRowValue(copy_u8Array[7]);
		MGPIO_voidSetPinValue(GPIO_PORTB, GPIO_PIN2,GPIO_PIN_HIGH);
		MSTK_voidDelayus(2500);
	}
